﻿function expandTile(id) {
    document.getElementById(id).setAttribute('style', 'top:0px');
}
function condenseTile(id) {
    document.getElementById(id).setAttribute('style', 'top:142px');
}
