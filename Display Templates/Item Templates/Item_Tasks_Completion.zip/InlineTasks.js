﻿function updateTask(e) {
	//debugger;
	if (e.checked) {
		var taskData = { 
			'PercentComplete':'1'
		}
	} else {
		var taskData = { 
			'PercentComplete':'0'
		}
	}
	
	
	var siteUrl = e.dataset.siteurl;
	var listId = e.dataset.listid;
	var itemId = e.dataset.itemid;

	//alert(itemId);
	updateListItem(siteUrl, listId, itemId, taskData)
	//Get List metadata
}

function updateListItem(siteUrl, listId, itemId, taskData) {

    var clientContext = new SP.ClientContext(siteUrl);
    var oList = clientContext.get_web().get_lists().getById(listId);

    this.oListItem = oList.getItemById(itemId);
	//debugger;
	for (var p in taskData) {
		oListItem.set_item(p, taskData[p]);	
	}
    if (taskData.PercentComplete == 1) {
    	var completed = true;
    } else {
    	var completed = false;
    }

    oListItem.update();

    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceeded(itemId, completed)), Function.createDelegate(this, this.onQueryFailed));
}

function onQuerySucceeded(itemId, completed) {
	
	if (completed == true) {
		document.getElementById('task_' + itemId).className = 'cbs-Item taskContainer completed';
	} else {
		document.getElementById('task_' + itemId).className = 'cbs-Item taskContainer';
	}
    addStatusMessage('Item ID (' + itemId + ') has been updated!', true);
}

function onQueryFailed(sender, args) {

    addStatusMessage('Unable to save item. Please verify that your property names match your SharePoint field names. Spaces should be _0x200_ ', false);
}


function addStatusMessage(msg, status) {

    var statusId = SP.UI.Status.addStatus(msg);

    if (status == true) {
        SP.UI.Status.setStatusPriColor(statusId, 'green');
        setTimeout(function () { removeStatus(statusId) }, 7000);
    } else {
        SP.UI.Status.setStatusPriColor(statusId, 'red');
        setTimeout(function () { removeStatus(statusId) }, 7000);
    }

}

function updateTaskAsync(siteUrl, listId, itemId) {

	// Getting our list items
	$.ajax({
		url: siteUrl + "/_api/web/lists('" + listId + "')/items(" + itemId + ")",
		method: "GET",
		headers: { "Accept": "application/json; odata=verbose" },
		success: function (data) {
			// Returning the results
			var now = new Date();
			var dueDate = new Date(data.d.DueDate);
			if (data.d.PercentComplete == 1) {
				document.getElementById('task_' + itemId).className += ' completed';
				$('#task_' + itemId + ' input:checkbox').prop( "checked", true );
			} else {
				document.getElementById('task_' + itemId).className = 'cbs-Item taskContainer';
				$('#task_' + itemId + ' input:checkbox').prop( "checked", false );
				
				if (dueDate < now) {
					document.getElementById('task_' + itemId).className += ' overdue';
				}

			}
			
			
		},
		error: function (data) {
			addStatusMessage('Failed to update task aysnc (' + itemId + '). Please refresh');
		}
	});
}

function showHideDetails(e) {
	
	if (e.parentNode.style.height == '17px') {	
		e.parentNode.style.height = 'auto';
		e.text = 'See Less';
	} else  {
		e.parentNode.style.height = '17px';
		e.text = 'See More';
	}

}

function showInModal(e) {
	
	
	var options = {
		'title': e.title,
		'url': e.dataset.href,
		'autoSize':true,
		'showClose': true
	}

	var value = SP.UI.ModalDialog.showModalDialog(options);
}

function RemoveAllStatus(id) {
    SP.UI.Status.removeStatus(id);
}